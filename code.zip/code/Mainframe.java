

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Mainframe {

    public static void main(String[] args) {
        JFrame frame = new JFrame("pets");
        JPanel panel = new JPanel();
        JLabel label = new JLabel();
        JButton button = new JButton("spawn");
        frame.setSize(800, 800);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        String[] listData = new String[]{"fox", "rabbit", "cat", "dog","sparkle"};

        
        final JComboBox comboBox = new JComboBox(listData);

        
        comboBox.addItemListener(new ItemListener() {
           
            public void itemStateChanged(ItemEvent e) {
                
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    
                     label.setIcon(new ImageIcon(comboBox.getSelectedItem()+"_main"+".png"));
                }
            }
        });

        

        
        

        
        button.addActionListener(new ActionListener() {
            
            public void actionPerformed(ActionEvent e) {
                
                System.out.println(listData[comboBox.getSelectedIndex()]);
                
            }
        });

        

        comboBox.setSelectedIndex(2);

        panel.add(button);
        panel.add(comboBox);
        panel.add(label);
        frame.setContentPane(panel);
        frame.setVisible(true);
    }

}
