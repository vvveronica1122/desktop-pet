import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.*;
import java.io.File;
import java.util.List;
import java.awt.event.*;


public class Common{
    static Point origin = new Point();
    public static void main(String[] args)  throws InterruptedException{

    
    JFrame frame = new JFrame();
    JPanel panel = new JPanel();
    JLabel label = new JLabel();

    frame.setSize(400, 400);
    
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLocation(0,150);
    frame.setUndecorated(true); 
    frame.setBackground(new Color(0,0,0,0));
    panel.setBackground(new Color(0,0,0,0));


    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    int screenWidth = (int)screenSize.getWidth();
    int screenHeight = (int)screenSize.getHeight();
   
    SwingUtilities.invokeLater(
                new Runnable() {
                    @Override
                    public void run() {
                        Eat(label,frame,panel);
                    }
                }
        );
    
    label.setIcon(new ImageIcon("down2@2x"+".png"));
    panel.add(label);
    frame.setContentPane(panel);
    frame.setVisible(true);
    Fall(screenHeight, frame, label, panel);

    frame.addMouseListener(new MouseAdapter() {
            
			public void mousePressed(MouseEvent e) {
				origin.x = e.getX();
				origin.y = e.getY();
                label.setIcon(new ImageIcon("down2@2x"+".png"));
                panel.add(label);
                frame.setContentPane(panel);
			}
            
            public void mouseReleased(MouseEvent e) {
				Fall(screenHeight, frame,label,panel);
                
                //Throw(frame, origin.x1,origin.x2,origin.y1,origin.y2);
            }
            public void mouseClicked(MouseEvent e) {
            //left
            // if(e.getButton()==e.BUTTON1){
            //     label.setIcon(new ImageIcon("upleft1@2x"+".png"));
            //     panel.add(label);
            //     frame.setContentPane(panel);
            //     try { Thread.sleep ( 2000 ) ;} catch (InterruptedException ie){}
            //     label.setIcon(new ImageIcon("upleft2@2x"+".png"));
            //     panel.add(label);
            //     frame.setContentPane(panel);
                
            
            // }
            // //right
            // if(e.getButton()==e.BUTTON3){
            //     label.setIcon(new ImageIcon("upright1@2x"+".png"));
            //     panel.add(label);
            //     frame.setContentPane(panel);
            //     try { Thread.sleep ( 2000 ) ;} catch (InterruptedException ie){}
            //     label.setIcon(new ImageIcon("upright2@2x"+".png"));
            //     panel.add(label);
            //     frame.setContentPane(panel);
            //}
        }
        
		});
    
    frame.addMouseMotionListener(new MouseMotionAdapter() {

        public void mouseDragged(MouseEvent e) {

            Point p = frame.getLocation();

            frame.setLocation(p.x + e.getX() - origin.x, p.y + e.getY() - origin.y);
            
        }
    });
    
    //Climb(screenHeight, screenWidth, frame,label);
    Wander(screenHeight, screenWidth,frame,label,panel);


    //Throw(frame);

    }

public static void Fall(int screenHeight, JFrame frame, JLabel label,JPanel panel)
    {Point p= frame.getLocationOnScreen();

    double v_y = 1.0;
    double a = 2;
    label.setIcon(new ImageIcon("down2@2x"+".png"));
    panel.add(label);
    frame.setContentPane(panel);
    
    while(p.y<screenHeight-400*1/2){
        p.y+=v_y;
        v_y+=a;
        frame.setLocation(p.x,p.y);
        try { Thread.sleep ( 25 ) ;} catch (InterruptedException ie){}

        System.out.println(p.x);System.out.println(p.y);
        }
    label.setIcon(new ImageIcon("down1@2x"+".png"));
    panel.add(label);
    frame.setContentPane(panel);
    frame.setLocation(p.x,screenHeight-200);
}
//climb
public static void Climb(int screenHeight, int screenWidth, JFrame frame, JLabel label)
    {do{
        Point p= frame.getLocationOnScreen();
        
        if(p.x<50 && p.y<screenHeight/2+100){
            frame.setLocation(-20,p.y);
        }
        if(p.x>screenWidth-150 && p.y<screenHeight/2+100){
            frame.setLocation(screenWidth-50,p.y);
        }
    }while(true);
}

public static void Wander(int screenHeight, int screenWidth, JFrame frame, JLabel label,JPanel panel)
    {   
    Point p= frame.getLocationOnScreen();
    double v_x=(Math.random()-Math.random())*20;
    while(p.y>=screenHeight-200){
        
        v_x=(Math.random()-Math.random())*75;
        
        for(int i =0; i<10; i++ ){
            Point p1= frame.getLocationOnScreen();
            p1.x+=v_x;
            if(v_x>0)
            {label.setIcon(new ImageIcon("right1@2x"+".png"));
            panel.add(label);
            frame.setContentPane(panel);
            try { Thread.sleep ( 250 ) ;} catch (InterruptedException ie){}
            label.setIcon(new ImageIcon("right2@2x"+".png"));
            panel.add(label);
            frame.setContentPane(panel);
            try { Thread.sleep ( 250 ) ;} catch (InterruptedException ie){}}
            
            if(v_x<0)
            {label.setIcon(new ImageIcon("left1@2x"+".png"));
            panel.add(label);
            frame.setContentPane(panel);
            try { Thread.sleep ( 250 ) ;} catch (InterruptedException ie){}
            label.setIcon(new ImageIcon("left2@2x"+".png"));
            panel.add(label);
            frame.setContentPane(panel);
            try { Thread.sleep ( 250 ) ;} catch (InterruptedException ie){}}

        if(p1.x+v_x>screenWidth-100 || p1.x+v_x<0+100){v_x=-v_x;}
        
        if(p1.y<screenHeight-200){break;}

        frame.setLocation(p1.x,p1.y);

        
        try { Thread.sleep ( 25 ) ;} catch (InterruptedException ie){}
        // label.setIcon(new ImageIcon("dog"+"_main"+".png"));

        
        
        
        try { Thread.sleep ( 50 ) ;} catch (InterruptedException ie){}
        System.out.println(p.x);System.out.println(p.y);}

        label.setIcon(new ImageIcon("mati2@2x"+".png"));
        panel.add(label);
        frame.setContentPane(panel);

        try { Thread.sleep ( 2000 ) ;} catch (InterruptedException ie){}
        
        label.setIcon(new ImageIcon("mati3@2x"+".png"));
        panel.add(label);
        frame.setContentPane(panel);

        try { Thread.sleep ( 2000 ) ;} catch (InterruptedException ie){}
        
        label.setIcon(new ImageIcon("mati2@2x"+".png"));
        panel.add(label);
        frame.setContentPane(panel);

        try { Thread.sleep ( 2000 ) ;} catch (InterruptedException ie){}

        label.setIcon(new ImageIcon("sleep2@2x"+".png"));
        panel.add(label);
        frame.setContentPane(panel);

        try { Thread.sleep ( 2500 ) ;} catch (InterruptedException ie){}
        } 
        
        }

    


    public static void Eat(JLabel label,JFrame frame,JPanel panel) {
         
        panel.add(new JScrollPane(label));

        DropTargetListener listener = new DropTargetListenerImpl(label);
        DropTarget dropTarget = new DropTarget(label, DnDConstants.ACTION_COPY_OR_MOVE, listener, true);

        panel.add(label);
        
        frame.setContentPane(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        }

    public static void Throw(JFrame frame,double x1,double x2,double y1,double y2)
        { while(true){
                
                double vx= (x2-x1)*2;
                double vy= (y2-y1)*2;
                Point p= frame.getLocationOnScreen();
                for(int i=0; i<10; i++)
                
                { p.x+=vx;
                p.y+=vy;
                  try { Thread.sleep ( 2500 ) ;
                } catch (InterruptedException ie){}
                frame.setLocation(p.x,p.y);
                
                System.out.println(p.x);System.out.println(p.y);}
                
            }
        }

    
    private static class DropTargetListenerImpl implements DropTargetListener {

        
        private JLabel label;

        public DropTargetListenerImpl(JLabel label) {
            this.label = label;
        }

        @Override
        public void dragEnter(DropTargetDragEvent dtde) {
            label.setIcon(new ImageIcon("jare2@2x"+".png"));
            
        }

        @Override
        public void dragOver(DropTargetDragEvent dtde) {
            label.setIcon(new ImageIcon("jare2@2x"+".png"));
        }

        @Override
        public void dragExit(DropTargetEvent dte) {
            label.setIcon(new ImageIcon("jare2@2x"+".png"));
        }

        @Override
        public void dropActionChanged(DropTargetDragEvent dtde) {
            label.setIcon(new ImageIcon("awake@2x"+".png"));
        }

        @Override
        public void drop(DropTargetDropEvent dtde) {
          
            //label.setIcon(new ImageIcon("awake@2x"+".png"));

            new Thread(() -> {
                int i=1;
                try{
                    while (i<=1){    
                        label.setIcon(new ImageIcon("jare2@2x"+".png"));
                        Thread.sleep(250);
                        label.setIcon(new ImageIcon("awake@2x"+".png"));
                        Thread.sleep(100);
                        i++;
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }).start();

            boolean isAccept = false;

    

            try {
                
                if (dtde.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                    
                    dtde.acceptDrop(DnDConstants.ACTION_COPY_OR_MOVE);
                    isAccept = true;

                   
                    List<File> files = (List<File>) dtde.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);

                    
                    if (files != null && files.size() > 0) {
                        StringBuilder filePaths = new StringBuilder();
                        for (File file : files) {
                            File file_d = new File(file.getAbsolutePath());
                            boolean deleted = file.delete();
                        }
                    }
                }
            } 
            catch (Exception e) {
                e.printStackTrace();
            }
            
            if (isAccept) {
                dtde.dropComplete(true);
            }
        }
    

}
}